<?php 
/*
  Pour changer le login et/ou le password, il suffit de supprimer ce fichier
  Et il sera automatiquement recr�� avec vos nouveaux identifiants lors de
  votre prochaine identification
*/
$auth['login'] = 'gabybob';
$auth['password'] = '405a5504c5d8d73f8c4a09984787c00c';
?>