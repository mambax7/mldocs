<?php
        header('location: http://www.jbc-explorer.com/?action=faq');
?>
